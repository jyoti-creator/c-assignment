﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Csharpassignment
{
    class Program
    {
        static void Main(String[] args)
        {
            float num1 = 0; float num2 = 0;
            Console.WriteLine("Type First Number");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Type Second Number");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Choose an option");
            Console.WriteLine("\ta Addition");
            Console.WriteLine("\ts Substraction");
            Console.WriteLine("\tm Multiply");
            Console.WriteLine("\td Division");
            Console.WriteLine("Your option");

            switch (Console.ReadLine())
            {

                case "a":
                    Console.WriteLine($"Your result: (num1) + (num2) = " + (num1 + num2));
                    break;
                case "s":
                    Console.WriteLine($"Your result: (num1) - (num2) = " + (num1 - num2));
                    break;
                case "m":
                    Console.WriteLine($"Your result: (num1) * (num2) = " + (num1 * num2));
                    break;
                case "d":
                    Console.WriteLine($"Your result: (num1) /(num2) = " + (num1 / num2));
                    break;
            }
            Console.WriteLine("Press any key to close");
            Console.ReadKey();
        }
    }
}


        
            
         
     
  
     


           
                        



